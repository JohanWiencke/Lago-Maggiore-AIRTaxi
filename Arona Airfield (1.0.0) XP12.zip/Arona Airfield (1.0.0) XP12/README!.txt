Installation: Just install all of the Libraries and put them into your Xplane 12/Custom Scenery Folder. Then put your Arona Airfield scenery into your Xplane 12/Custom Scenery Folder.
Start up the game and everything should work!

Copyright: DO NOT PUT THIS SCENERY FOR DOWNLOAD ON ANY WEBSITE OR SELL IT ANYWHERE!

Link's to the Libraries are in the: Libraries for Arona Airfield.txt

Enjoy!